<?php
define('site_Url', 'http://localhost/crm/'); 
?>